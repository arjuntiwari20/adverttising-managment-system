# Ad-Man-Backend
Backend API for Ad-Man (DBMS Project.)
