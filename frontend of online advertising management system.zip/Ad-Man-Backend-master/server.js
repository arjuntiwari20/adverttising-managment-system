const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors')
const bcrypt = require('bcrypt-nodejs')
var db = require('knex')({
    client: 'pg',
    connection: {
      host : '127.0.0.1',
      user : 'mayank',
      password : '060616',
      database : 'adman'
    }
  });

const app = express()
app.use(bodyParser.json())
app.use(cors())

app.post('/getdetails', (req,res) => {
    db('login').join('users','login.accid','=','users.accid')
    .select('*')
    .where('login.email','=',req.body.Email)
    .then(user => {
        res.json(user)
    })
})

app.post('/signin', (req,res) => {
    db.select('*').from('login').where('email','=',req.body.Email)
    .then(user => {
        if (user.length===0) {
            // User does not exist
            res.json('no')
        }
        else {
            const isValid = bcrypt.compareSync(req.body.Password, user[0].hash); // true
            if (isValid) {
                //Success
                res.json('succ')
                console.log('User ',user[0].accid,' signed in.')
            }
            else {
                //Failed
                res.json('fail')
            }
        }
    })
})

app.put('/deletead',(req,res) => {
    db('ad').where('adid',req.body.AdId).del()
    .then(console.log('Deleted Ad : ', req.body.AdId))
})

app.put('/deleteplatform',(req,res) => {
    db('platform').where('platformid',req.body.PID).del()
    .then(console.log('Platform deleted : ', req.body.PID))
})

app.post('/getads',(req,res)=>{
    db.select('*').from('ad').where('accid','=',req.body.AccId)
    .then(ads => {
        res.json(ads)
    })
})

app.post('/postrequest',(req,res) => {
    const { from_accid, to_accid, to_adid } = req.body;
    db('requests').insert({
        accid_from: from_accid,
        accid_to: to_accid,
        to_adid : to_adid
    })
    .then(res.json('succ'))

})

app.post('/checkrequest',(req,res) => {
    const { from_accid, to_accid,to_adid } = req.body;
    db('requests').where({
        accid_from: from_accid,
        accid_to: to_accid,
        to_adid: to_adid
    }).select('*')
    .then(requests => {
        res.json(requests)
    })
})


app.get('/getallads',(req,res) =>{
    db.select('*').from('ad')
    .then(ads => {
        res.json(ads)
    })
})

app.post('/getplatforms',(req,res)=> {
    db.select('*').from('platform').where('accid','=',req.body.AccId)
    .then(pl => {
        res.json(pl)
    })
})


app.put('/updateprofile',(req,res)=>{
    db.transaction(trx => {
        trx('login').where('accid',req.body.AccId)
        .update({
            email: req.body.Email
        })
        .returning('accid')
        .then(accID => {
            return trx('users')
            .returning('*')
            .where('accid',accID[0])
            .update({
                fname: req.body.FirstName,
                lname: req.body.LastName,
                phonenumber: req.body.PhoneNumber
            })
            .then(user => {
                console.log('Profile updated for user : ',accID[0])
                res.json('updated')
            })
        })
        .then(trx.commit)
        .catch(trx.rollback)
    })
    .catch(err => console.log(err))

})

app.post('/postad',(req,res) => {
    const { AccId, CompanyName, AdTitle, Desc} = req.body;
    db('ad').insert({
        accid : AccId,
        company: CompanyName,
        adtitle : AdTitle,
        description : Desc 
    })
    .then(res.json('succ'))
    .then(
        console.log('Ad posted')
    )
})

app.post('/host',(req,res) => {
    const {AccId, PlatformName, URL, type } = req.body;
    db('platform').insert({
        accid : AccId,
        platform_name: PlatformName,
        platformurl: URL,
        platformtype: type
    })
    .then(res.json('succ'))
    .then(console.log('Platform Hosted.'))
})

app.post('/signup',(req,res) => {
    const {FirstName, LastName, Email,PhoneNumber, Password, date} = req.body;  
    const hash = bcrypt.hashSync(Password);
    db.transaction(trx => {
        trx.insert({
            hash:hash,
            email:Email
        })
        .into('login')
        .returning('accid')
        .then(accID => {
            return trx('users')
            .returning('*')
            .insert({
                accid: accID[0],
                fname: FirstName,
                lname: LastName,
                // email: Email,
                phonenumber: PhoneNumber,
                dateofbirth: date
            })
            .then(user => {
                console.log('Successfully signed up - AccID ', user[0].accid)
                res.json('succ')
            })
        })
        .then(trx.commit)
        .catch(trx.rollback)
    })
    .catch(err => console.log(err))

})

app.listen(5000, () => {
    console.log('App is running on PORT 5000.')
})
